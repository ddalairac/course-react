export const procesoPesado = ( iteraciones ) => {

    for( let i = 0; i < iteraciones; i ++ ){
        console.log('Ahí vamos....');
    }

    return `${ iteraciones } iteraciones realizadas.`;
}